<?php $_config_vars = array (
  'pageTitle' => 'Домашка 15',
  'style' => 'bootstrap.min.css',
); ?>