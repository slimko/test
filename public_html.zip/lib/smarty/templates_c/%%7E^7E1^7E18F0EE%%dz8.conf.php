<?php $_config_vars = array (
  'cssfile' => './style.css',
); ?>