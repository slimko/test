<?php /* Smarty version 2.6.28, created on 2014-12-10 13:52:58
         compiled from header_mobile.tpl */ ?>
<HTML>
<HEAD>
<TITLE>MOBILE: <?php echo $this->_tpl_vars['title']; ?>
 / <?php echo $this->_tpl_vars['var1']; ?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">