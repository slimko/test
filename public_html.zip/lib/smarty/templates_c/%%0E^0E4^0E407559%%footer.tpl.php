<?php /* Smarty version 2.6.28, created on 2016-03-17 01:54:55
         compiled from footer.tpl */ ?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="http://<?php echo $_SERVER['SERVER_NAME']; ?>
/js/bootstrap.min.js"></script>
    <script src="http://<?php echo $_SERVER['SERVER_NAME']; ?>
/js/main.js"></script>
    </div>
</body>
</html>